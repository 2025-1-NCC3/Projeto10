package br.com.fecapccp.ubergirls.util;

public class Constants {
    public static final String BASE_URL = "https://7pmt2p-4000.csb.app/";
}
