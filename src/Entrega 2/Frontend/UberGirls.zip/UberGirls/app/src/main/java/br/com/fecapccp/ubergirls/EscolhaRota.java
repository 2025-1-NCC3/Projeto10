package br.com.fecapccp.ubergirls;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class EscolhaRota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.escolharota_main);
    }
}
