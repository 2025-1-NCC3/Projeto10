public class EscolhaRota {
}
